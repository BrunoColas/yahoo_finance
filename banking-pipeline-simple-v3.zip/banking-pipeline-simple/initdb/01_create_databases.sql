-- Runs once, the first time the postgres volume is created.
CREATE DATABASE stock_pipeline_db;
CREATE DATABASE metabase;
