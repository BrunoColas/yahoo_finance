from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from datetime import datetime, timedelta
import yfinance as yf
import pandas as pd
from file_store import save_file

# -----------------------------
# CONFIG
# -----------------------------

LOOKBACK_DAYS = 365  # original project used 60; 365 leaves enough rows after 30-day rolling windows
BANK_TICKERS = [
    "HDFCBANK.NS",
    "ICICIBANK.NS",
    "SBIN.NS",
    "AXISBANK.NS",
    "KOTAKBANK.NS",
    "INDUSINDBK.NS",
    "BANKBARODA.NS",
    "PNB.NS",
]

LOCAL_CSV_PATH = "/tmp/banking_raw_prices.csv"

# -----------------------------
# TASK FUNCTION
# -----------------------------


def fetch_and_store_raw_data():
    print("📥 Starting banking stock ingestion")

    today = datetime.utcnow().date()
    end_date = today - timedelta(days=1)
    start_date = end_date - timedelta(days=LOOKBACK_DAYS)

    print(f"Fetching data from {start_date} to {end_date}")

    all_data = []

    for ticker in BANK_TICKERS:
        print(f"Downloading {ticker}")

        df = yf.download(
            ticker,
            start=start_date,
            end=end_date + timedelta(days=1),
            interval="1d",
            progress=False,
        )

        if df.empty:
            print(f"⚠️ No data for {ticker}")
            continue

        df.reset_index(inplace=True)

        # ✅ flatten multiindex columns safely
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]

        # ✅ lowercase
        df.columns = [c.lower() for c in df.columns]

        df["symbol"] = ticker

        df = df[["date", "symbol", "open", "high", "low", "close", "volume"]]

        all_data.append(df)

    if not all_data:
        raise ValueError("No stock data downloaded")

    final_df = pd.concat(all_data)
    final_df.sort_values(["symbol", "date"], inplace=True)
    final_df["date"] = pd.to_datetime(final_df["date"]).dt.date

    # -----------------------------
    # Save CSV
    # -----------------------------
    final_df.to_csv(LOCAL_CSV_PATH, index=False)
    print(f"✅ CSV saved at {LOCAL_CSV_PATH}")

    # -----------------------------
    # Save CSV copy
    # -----------------------------
    object_name = f"raw/banking_raw_{end_date}.csv"
    save_file(LOCAL_CSV_PATH, object_name)

    print(f"✅ Saved copy → {object_name}")

    # -----------------------------
    # Postgres storage
    # -----------------------------
    pg_hook = PostgresHook(postgres_conn_id="stock_pipeline_postgres")
    conn = pg_hook.get_conn()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS banking_raw_prices (
            date DATE,
            symbol TEXT,
            open FLOAT,
            high FLOAT,
            low FLOAT,
            close FLOAT,
            volume BIGINT
        );
    """
    )

    cursor.execute("DELETE FROM banking_raw_prices;")

    for r in final_df.itertuples(index=False):
        cursor.execute(
            """
            INSERT INTO banking_raw_prices
            (date, symbol, open, high, low, close, volume)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
            """,
            (
                r.date,
                r.symbol,
                float(r.open),
                float(r.high),
                float(r.low),
                float(r.close),
                int(r.volume),
            ),
        )

    conn.commit()
    cursor.close()
    conn.close()

    print("✅ Data stored in Postgres")


# -----------------------------
# DAG
# -----------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_stock_ingestion_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["stock", "banking", "ingestion"],
) as dag:

    ingest_task = PythonOperator(
        task_id="fetch_and_store_banking_data",
        python_callable=fetch_and_store_raw_data,
    )

    ingest_task
