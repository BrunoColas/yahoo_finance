"""Tiny helper: keep a CSV copy of every pipeline stage in ./data (mounted at /opt/airflow/data)."""
import os
import shutil

DATA_DIR = os.environ.get("PIPELINE_DATA_DIR", "/opt/airflow/data")


def save_file(local_path, object_name):
    """Copy local_path to DATA_DIR/object_name (e.g. raw/banking_raw_2026-11-26.csv)."""
    target = os.path.join(DATA_DIR, object_name)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copyfile(local_path, target)
    print(f"✅ Saved copy -> {target}")
    return target
