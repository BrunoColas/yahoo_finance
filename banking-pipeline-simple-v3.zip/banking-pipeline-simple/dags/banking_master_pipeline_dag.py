from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from datetime import datetime, timedelta

default_args = {
    "owner": "airflow",
    "retries": 0,
}

with DAG(
    dag_id="banking_master_pipeline_dag",
    start_date=datetime(2025, 1, 1),
    schedule_interval="30 0 * * 1-5",  # 6:00 AM IST, Monday to Friday only
    catchup=False,  # set True to back-fill missed days
    max_active_runs=1,  # ← only one run at a time
    tags=["master", "pipeline"],
    default_args={
        "retries": 2,
        "retry_delay": timedelta(minutes=5),
        "email_on_failure": False,
    },
) as dag:

    trigger_dag1 = TriggerDagRunOperator(
        task_id="trigger_ingestion",
        trigger_dag_id="banking_stock_ingestion_dag",
        wait_for_completion=True,
        poke_interval=30,
    )
    trigger_dag2 = TriggerDagRunOperator(
        task_id="trigger_indicators",
        trigger_dag_id="banking_indicator_dag",
        wait_for_completion=True,
        poke_interval=30,
    )
    trigger_dag3 = TriggerDagRunOperator(
        task_id="trigger_fundamentals",
        trigger_dag_id="banking_fundamentals_dag",
        wait_for_completion=True,
        poke_interval=30,
    )
    trigger_dag4 = TriggerDagRunOperator(
        task_id="trigger_features",
        trigger_dag_id="banking_feature_engineering_dag",
        wait_for_completion=True,
        poke_interval=30,
    )
    trigger_dag5 = TriggerDagRunOperator(
        task_id="trigger_scoring",
        trigger_dag_id="banking_scoring_dag",
        wait_for_completion=True,
        poke_interval=30,
    )
    trigger_dag6 = TriggerDagRunOperator(
        task_id="trigger_dashboard",
        trigger_dag_id="banking_dashboard_dag",
        wait_for_completion=True,
        poke_interval=30,
    )

    (
        trigger_dag1
        >> trigger_dag2
        >> trigger_dag3
        >> trigger_dag4
        >> trigger_dag5
        >> trigger_dag6
    )
