from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from datetime import datetime, timedelta
import pandas as pd
from file_store import save_file

LOCAL_OUT = "/tmp/banking_scores.csv"


# -------------------------------------------------
# TASK
# -------------------------------------------------


def score_stocks():

    print("🏆 Starting Scoring DAG")

    pg = PostgresHook(postgres_conn_id="stock_pipeline_postgres")

    df = pg.get_pandas_df(
        """
        SELECT * FROM banking_features_final
    """
    )

    print("Feature rows:", len(df))

    # -----------------------------
    # take latest row per stock
    # -----------------------------
    df["date"] = pd.to_datetime(df["date"])

    latest = df.sort_values("date").groupby("symbol").tail(1).copy()

    # -----------------------------
    # scoring rules
    # -----------------------------

    latest["trend_score"] = latest["trend_signal"] * 2
    latest["momentum_score"] = latest["momentum_flag"] * 2
    latest["volume_score"] = latest["volume_flag"] * 1

    # valuation score
    latest["valuation_score"] = 0
    latest.loc[latest["pe_ratio"] < 12, "valuation_score"] = 2
    latest.loc[
        (latest["pe_ratio"] >= 12) & (latest["pe_ratio"] <= 20), "valuation_score"
    ] = 1

    # risk score
    latest["risk_score"] = (latest["beta"] < 0.5).astype(int)

    # drawdown opportunity
    latest["pullback_score"] = (latest["drawdown_pct"] < -5).astype(int)

    # -----------------------------
    # total score
    # -----------------------------
    score_cols = [
        "trend_score",
        "momentum_score",
        "volume_score",
        "valuation_score",
        "risk_score",
        "pullback_score",
    ]

    latest["total_score"] = latest[score_cols].sum(axis=1)

    # -----------------------------
    # ranking
    # -----------------------------
    ranked = latest.sort_values("total_score", ascending=False)

    print("Ranked stocks:", len(ranked))

    # -----------------------------
    # save CSV
    # -----------------------------
    ranked.to_csv(LOCAL_OUT, index=False)

    # -----------------------------
    # Save CSV copy
    # -----------------------------
    today = datetime.utcnow().date()

    obj = f"scores/banking_scores_{today}.csv"
    save_file(LOCAL_OUT, obj)

    print("✅ Scores saved to data folder")

    # -----------------------------
    # store Postgres
    # -----------------------------
    conn = pg.get_conn()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS banking_stock_scores (
            symbol TEXT,
            total_score INT,
            trend_score INT,
            momentum_score INT,
            volume_score INT,
            valuation_score INT,
            risk_score INT,
            pullback_score INT,
            pe_ratio FLOAT,
            beta FLOAT,
            close FLOAT
        );
    """
    )

    cur.execute("DELETE FROM banking_stock_scores;")

    for _, r in ranked.iterrows():
        cur.execute(
            """
            INSERT INTO banking_stock_scores VALUES (
            %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
            )
        """,
            (
                r["symbol"],
                int(r["total_score"]),
                int(r["trend_score"]),
                int(r["momentum_score"]),
                int(r["volume_score"]),
                int(r["valuation_score"]),
                int(r["risk_score"]),
                int(r["pullback_score"]),
                r["pe_ratio"],
                r["beta"],
                r["close"],
            ),
        )

    conn.commit()
    cur.close()
    conn.close()

    print("✅ Scores stored in Postgres")


# -------------------------------------------------
# DAG
# -------------------------------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_scoring_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["stock", "scoring"],
) as dag:

    task = PythonOperator(
        task_id="score_stocks",
        python_callable=score_stocks,
    )

    task
