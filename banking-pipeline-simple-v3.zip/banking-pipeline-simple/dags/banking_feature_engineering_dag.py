from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from datetime import datetime, timedelta
import pandas as pd
from file_store import save_file

LOCAL_OUT = "/tmp/banking_features.csv"


# -------------------------------------------------
# TASK
# -------------------------------------------------


def build_feature_table():

    print("🧹 Starting Feature Engineering DAG")

    pg = PostgresHook(postgres_conn_id="stock_pipeline_postgres")

    indicators = pg.get_pandas_df(
        """
        SELECT * FROM banking_indicators
    """
    )

    fundamentals = pg.get_pandas_df(
        """
        SELECT * FROM banking_fundamentals
    """
    )

    print("Indicator rows:", len(indicators))
    print("Fundamental rows:", len(fundamentals))

    # -----------------------------
    # Join on symbol
    # -----------------------------
    df = indicators.merge(fundamentals, on="symbol", how="left")

    # -----------------------------
    # Handle missing fundamentals
    # -----------------------------
    df["pe_ratio"] = df["pe_ratio"].fillna(df["pe_ratio"].median())
    df["beta"] = df["beta"].fillna(1.0)

    # -----------------------------
    # Derived decision features
    # -----------------------------

    # trend signal
    df["trend_signal"] = (df["ma20"] > df["ma30"]).astype(int)

    # momentum flag
    df["momentum_flag"] = ((df["rsi"] > 45) & (df["macd"] > 0)).astype(int)

    # volume strength flag
    df["volume_flag"] = (df["volume_spike_ratio"] > 1.5).astype(int)

    # -----------------------------
    # Select final columns (controlled set)
    # -----------------------------
    final_cols = [
        "date",
        "symbol",
        "close",
        "volume",
        "price_change_pct",
        "ma20",
        "ma30",
        "rsi",
        "macd",
        "volatility_20d",
        "drawdown_pct",
        "volume_spike_ratio",
        "pe_ratio",
        "market_cap",
        "beta",
        "trend_signal",
        "momentum_flag",
        "volume_flag",
    ]

    final_df = df[final_cols].copy()

    print("Final feature rows:", len(final_df))

    # -----------------------------
    # Save CSV
    # -----------------------------
    final_df.to_csv(LOCAL_OUT, index=False)

    # -----------------------------
    # Save CSV copy
    # -----------------------------
    today = datetime.utcnow().date()

    obj = f"features/banking_features_{today}.csv"
    save_file(LOCAL_OUT, obj)

    print("✅ Features saved to data folder")

    # -----------------------------
    # Store Postgres
    # -----------------------------
    conn = pg.get_conn()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS banking_features_final (
            date DATE,
            symbol TEXT,
            close FLOAT,
            volume BIGINT,

            price_change_pct FLOAT,
            ma20 FLOAT,
            ma30 FLOAT,
            rsi FLOAT,
            macd FLOAT,

            volatility_20d FLOAT,
            drawdown_pct FLOAT,
            volume_spike_ratio FLOAT,

            pe_ratio FLOAT,
            market_cap BIGINT,
            beta FLOAT,

            trend_signal INT,
            momentum_flag INT,
            volume_flag INT
        );
    """
    )

    cur.execute("DELETE FROM banking_features_final;")

    for _, r in final_df.iterrows():
        cur.execute(
            """
            INSERT INTO banking_features_final VALUES (
            %s,%s,%s,%s,
            %s,%s,%s,%s,%s,
            %s,%s,%s,
            %s,%s,%s,
            %s,%s,%s
            )
        """,
            tuple(r),
        )

    conn.commit()
    cur.close()
    conn.close()

    print("✅ Feature table stored in Postgres")


# -------------------------------------------------
# DAG
# -------------------------------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_feature_engineering_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["stock", "features"],
) as dag:

    task = PythonOperator(
        task_id="build_feature_table",
        python_callable=build_feature_table,
    )

    task
