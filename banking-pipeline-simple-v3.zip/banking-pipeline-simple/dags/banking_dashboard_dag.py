from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from datetime import datetime, timedelta
import pandas as pd
from file_store import save_file
import os



# -----------------------------
# TASK
# -----------------------------


def build_dashboard_tables():
    print("📊 Building dashboard tables — NO ML VERSION")

    pg = PostgresHook(postgres_conn_id="stock_pipeline_postgres")

    # -----------------------------
    # Load features
    # -----------------------------
    features = pg.get_pandas_df(
        """
        SELECT *
        FROM banking_features_final
    """
    )

    print("Features rows:", len(features))

    # -----------------------------
    # Detect score column
    # -----------------------------
    col_df = pg.get_pandas_df(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = 'banking_stock_scores'
    """
    )

    score_col = None
    for c in col_df["column_name"]:
        if "score" in c.lower():
            score_col = c
            break

    if score_col is None:
        raise ValueError("❌ No score column found in banking_stock_scores")

    print("✅ Using score column:", score_col)

    # -----------------------------
    # Load scores
    # -----------------------------
    scores = pg.get_pandas_df(
        f"""
        SELECT symbol, {score_col} as final_score
        FROM banking_stock_scores
    """
    )

    print("Scores rows:", len(scores))

    # -----------------------------
    # Merge
    # -----------------------------
    df = features.merge(scores, on="symbol", how="left")

    print("Merged rows:", len(df))

    # -----------------------------
    # Latest snapshot
    # -----------------------------
    latest = df.sort_values("date").groupby("symbol").tail(1)

    # -----------------------------
    # Top picks
    # -----------------------------
    top = latest.sort_values("final_score", ascending=False).head(10)

    # -----------------------------
    # Store to Postgres (safe SQL way)
    # -----------------------------
    conn = pg.get_conn()
    cur = conn.cursor()

    cur.execute("DROP TABLE IF EXISTS banking_dashboard_latest")
    cur.execute(
        """
        CREATE TABLE banking_dashboard_latest AS
        SELECT *
        FROM banking_features_final
        WHERE 1=0
    """
    )

    cur.execute(
        """
        ALTER TABLE banking_dashboard_latest
        ADD COLUMN final_score FLOAT
    """
    )

    for r in latest.itertuples(index=False):
        cur.execute(
            """
            INSERT INTO banking_dashboard_latest
            SELECT f.*, %s
            FROM banking_features_final f
            WHERE f.symbol=%s AND f.date=%s
        """,
            (r.final_score, r.symbol, r.date),
        )

    cur.execute("DROP TABLE IF EXISTS banking_dashboard_top_picks")
    cur.execute(
        """
        CREATE TABLE banking_dashboard_top_picks AS
        SELECT *
        FROM banking_dashboard_latest
        ORDER BY final_score DESC
        LIMIT 10
    """
    )

    conn.commit()
    cur.close()
    conn.close()

    print("✅ Dashboard tables stored in Postgres")

    # -----------------------------
    # EXPORT CSV
    # -----------------------------
    latest_csv = "/tmp/dashboard_latest.csv"
    top_csv = "/tmp/dashboard_top_picks.csv"

    latest.to_csv(latest_csv, index=False)
    top.to_csv(top_csv, index=False)

    print("✅ CSV files created")

    # -----------------------------
    # Save CSV copy
    # -----------------------------
    today = datetime.utcnow().date()
    save_file(latest_csv, f"dashboard/banking_dashboard_latest_{today}.csv")
    save_file(top_csv, f"dashboard/banking_dashboard_top_picks_{today}.csv")

    print("✅ Saved dashboard CSVs to data folder")


# -----------------------------
# DAG
# -----------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_dashboard_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["dashboard"],
) as dag:

    build_dashboard = PythonOperator(
        task_id="build_dashboard",
        python_callable=build_dashboard_tables,
    )

    build_dashboard
