from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from datetime import datetime, timedelta
import yfinance as yf
import pandas as pd
from file_store import save_file

BANK_TICKERS = [
    "HDFCBANK.NS",
    "ICICIBANK.NS",
    "SBIN.NS",
    "AXISBANK.NS",
    "KOTAKBANK.NS",
    "INDUSINDBK.NS",
    "BANKBARODA.NS",
    "PNB.NS",
]

LOCAL_OUT = "/tmp/banking_fundamentals.csv"


# -------------------------------------------------
# TASK
# -------------------------------------------------


def fetch_fundamentals():

    print("🏢 Fetching fundamentals")

    rows = []

    for ticker in BANK_TICKERS:
        print(f"Fetching info for {ticker}")

        t = yf.Ticker(ticker)
        info = t.info

        pe = info.get("trailingPE")
        market_cap = info.get("marketCap")
        beta = info.get("beta")
        eps = info.get("trailingEps")

        rows.append(
            {
                "symbol": ticker,
                "pe_ratio": pe,
                "market_cap": market_cap,
                "beta": beta,
                "eps": eps,
            }
        )

    df = pd.DataFrame(rows)

    print("Fundamental rows:", len(df))

    # -----------------------------
    # Save CSV
    # -----------------------------
    df.to_csv(LOCAL_OUT, index=False)

    # -----------------------------
    # Save CSV copy
    # -----------------------------
    today = datetime.utcnow().date()

    obj = f"fundamentals/banking_fundamentals_{today}.csv"
    save_file(LOCAL_OUT, obj)

    print("✅ Saved fundamentals to data folder")

    # -----------------------------
    # Store Postgres
    # -----------------------------
    pg_hook = PostgresHook(postgres_conn_id="stock_pipeline_postgres")
    conn = pg_hook.get_conn()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS banking_fundamentals (
            symbol TEXT PRIMARY KEY,
            pe_ratio FLOAT,
            market_cap BIGINT,
            beta FLOAT,
            eps FLOAT
        );
    """
    )

    cur.execute("DELETE FROM banking_fundamentals;")

    for _, r in df.iterrows():
        cur.execute(
            """
            INSERT INTO banking_fundamentals
            VALUES (%s,%s,%s,%s,%s)
        """,
            (
                r["symbol"],
                r["pe_ratio"],
                r["market_cap"],
                r["beta"],
                r["eps"],
            ),
        )

    conn.commit()
    cur.close()
    conn.close()

    print("✅ Fundamentals stored in Postgres")


# -------------------------------------------------
# DAG
# -------------------------------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_fundamentals_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["stock", "fundamentals"],
) as dag:

    task = PythonOperator(
        task_id="fetch_fundamental_data",
        python_callable=fetch_fundamentals,
    )

    task
