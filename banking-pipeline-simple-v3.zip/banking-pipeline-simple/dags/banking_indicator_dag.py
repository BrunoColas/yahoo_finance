from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from file_store import save_file
from datetime import datetime, timedelta
import pandas as pd
import numpy as np


# --------------------------------
# Indicator Functions
# --------------------------------


def compute_rsi(series, period=14):
    delta = series.diff()

    gain = (delta.where(delta > 0, 0)).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()

    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


# --------------------------------
# TASK FUNCTION
# --------------------------------


def build_indicators():

    print("📊 Building technical indicators")

    pg = PostgresHook(postgres_conn_id="stock_pipeline_postgres")

    df = pg.get_pandas_df(
        """
        SELECT date, symbol, open, high, low, close, volume
        FROM banking_raw_prices
        ORDER BY symbol, date
    """
    )

    if df.empty:
        raise ValueError("No raw data found")

    final_list = []

    for symbol, g in df.groupby("symbol"):

        g = g.sort_values("date").copy()

        # -------- PRICE CHANGE --------
        g["price_change_pct"] = g["close"].pct_change() * 100

        # -------- MOVING AVERAGES --------
        g["ma20"] = g["close"].rolling(20).mean()
        g["ma30"] = g["close"].rolling(30).mean()

        # -------- RSI --------
        g["rsi"] = compute_rsi(g["close"])

        # -------- MACD --------
        ema12 = g["close"].ewm(span=12).mean()
        ema26 = g["close"].ewm(span=26).mean()
        g["macd"] = ema12 - ema26

        # -------- VOLATILITY (Better — uses High/Low) --------
        g["hl_range_pct"] = (g["high"] - g["low"]) / g["close"] * 100
        g["volatility_20d"] = g["hl_range_pct"].rolling(20).mean()

        # -------- VOLUME METRICS --------
        g["avg_volume_20d"] = g["volume"].rolling(20).mean()
        g["volume_spike_ratio"] = g["volume"] / g["avg_volume_20d"]

        # -------- DRAWDOWN --------
        rolling_max = g["close"].rolling(30).max()
        g["drawdown_pct"] = (g["close"] - rolling_max) / rolling_max * 100

        final_list.append(g)

    final_df = pd.concat(final_list)

    # -------- Drop warmup rows --------
    final_df = final_df.dropna()

    print("Rows after indicator calc:", len(final_df))

    LOCAL_PATH = "/tmp/banking_indicators.csv"
    final_df.to_csv(LOCAL_PATH, index=False)

    save_file(LOCAL_PATH, f"indicators/banking_indicators.csv")

    print("✅ Indicators saved to data folder")

    # --------------------------------
    # STORE TO POSTGRES
    # --------------------------------

    conn = pg.get_conn()
    cur = conn.cursor()

    cur.execute("DROP TABLE IF EXISTS banking_indicators")

    cur.execute(
        """
        CREATE TABLE banking_indicators (
            date DATE,
            symbol TEXT,
            close FLOAT,
            volume BIGINT,
            price_change_pct FLOAT,
            ma20 FLOAT,
            ma30 FLOAT,
            rsi FLOAT,
            macd FLOAT,
            volatility_20d FLOAT,
            drawdown_pct FLOAT,
            volume_spike_ratio FLOAT
        );
    """
    )

    for r in final_df.itertuples(index=False):
        cur.execute(
            """
            INSERT INTO banking_indicators
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
            (
                r.date,
                r.symbol,
                float(r.close),
                int(r.volume),
                float(r.price_change_pct),
                float(r.ma20),
                float(r.ma30),
                float(r.rsi),
                float(r.macd),
                float(r.volatility_20d),
                float(r.drawdown_pct),
                float(r.volume_spike_ratio),
            ),
        )

    conn.commit()
    cur.close()
    conn.close()

    print("✅ Indicators stored")


# --------------------------------
# DAG
# --------------------------------

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="banking_indicator_dag",
    default_args=default_args,
    start_date=datetime(2025, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["stock", "indicators"],
) as dag:

    task = PythonOperator(task_id="build_indicators", python_callable=build_indicators)

    task
